const nome = prompt("Olá, Digite o seu nome: ");
const saudacao = prompt("Seja Bem Vindo " + nome + " !!!");
